export default {
  name: "aboutProfile",
  title: "aboutProfile",
  type: "document",
  fields: [
    {
      name: "img",
      title: "img",
      type: "image",
    },
  ],
};
