const MenuItems = [
  {
    id: 1,
    label: "Home",
    url: "/",
    active: true,
  },
  {
    id: 2,
    label: "About",
    url: "/about",
    active: false,
  },
  {
    id: 3,
    label: "Project",
    url: "/project",
    active: false,
  },
];

export default MenuItems;
