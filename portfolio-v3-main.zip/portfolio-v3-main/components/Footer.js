import React from "react";

const Footer = () => {
  return (
    <div className="relative bottom-0 mt-10 text-gray-500">
      <p className="text-xs">
        Copyright © 2022 Mengly Cheng. All rights reserved.
      </p>{" "}
    </div>
  );
};

export default Footer;
